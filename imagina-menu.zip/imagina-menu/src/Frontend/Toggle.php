<?php
declare(strict_types=1);

namespace ImaginaMenu\Frontend;

defined( 'ABSPATH' ) || exit;

/**
 * Botón para abrir el panel desde el tema: shortcode [imagina_menu_toggle], bloque de Gutenberg y
 * función imagina_menu_toggle(). Funciona sin JS (popovertarget).
 */
final class Toggle {

	/**
	 * [imagina_menu_toggle label="Todo" style="solid" only="desktop"]
	 *
	 * @param array<string, string>|string $atts
	 */
	public static function shortcode( $atts = array() ): string {
		$atts = shortcode_atts(
			array(
				'label' => '',
				'class' => '',
				'style' => '', // '' (transparente, toma el color de la cabecera) | solid | outline
				'only'  => '', // '' | desktop | mobile (según el breakpoint de los ajustes)
			),
			is_array( $atts ) ? $atts : array(),
			'imagina_menu_toggle'
		);
		$profile = Frontend::profile();
		if ( ! $profile || '' === $profile['parts']['drawer_guest'] ) {
			return '';
		}
		$label = sanitize_text_field( $atts['label'] );
		$class = 'imm-toggle';
		if ( in_array( $atts['style'], array( 'solid', 'outline' ), true ) ) {
			$class .= ' imm-toggle--' . $atts['style'];
		}
		if ( in_array( $atts['only'], array( 'desktop', 'mobile' ), true ) ) {
			$class .= ' imm-only-' . $atts['only'];
		}
		$class = trim( $class . ' ' . implode( ' ', array_map( 'sanitize_html_class', explode( ' ', $atts['class'] ) ) ) );
		// Su CSS va junto al primer botón de la página (solo en las páginas que lo tienen). Antes de la
		// v0.5.10 iba en el CSS crítico (las configuraciones sin recompilar no lo traen: ya lo tienen).
		static $css_done = false;
		$css = '';
		if ( ! $css_done && '' !== (string) ( $profile['toggle_css'] ?? '' ) ) {
			$css      = '<style id="imm-toggle-css">' . $profile['toggle_css'] . '</style>';
			$css_done = true;
		}
		return $css . '<button type="button" class="' . esc_attr( $class ) . '" popovertarget="imm-drawer" aria-controls="imm-drawer" aria-expanded="false" aria-label="' . esc_attr( '' !== $label ? $label : __( 'Abrir menú', 'imagina-menu' ) ) . '" data-imm-open>'
			. '<svg class="imm-i" aria-hidden="true" focusable="false"><use href="#imm-i-' . esc_attr( $profile['trigger']['icon'] ?? 'menu' ) . '"/></svg>'
			. ( '' !== $label ? '<span>' . esc_html( $label ) . '</span>' : '' )
			. '</button>';
	}
}
